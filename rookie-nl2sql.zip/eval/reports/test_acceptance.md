# NL2SQL Benchmark Report

**Generated:** 2025-12-18T12:35:24.147033

---

## 📊 Summary

- **Total Cases:** 1
- **Total Time:** 9.71s
- **Avg Time/Case:** 9.71s

## 📈 Metrics

| Metric | Value |
|--------|-------|
| SQL Exact Match Rate | 0.0% |
| SQL Semantic Match Rate | 0.0% |
| Execution Success Rate | 100.0% |
| Execution Accuracy Rate | 100.0% |

## 📂 Results by Category

| Category | Total | Exact Match | Execution Success |
|----------|-------|-------------|-------------------|
| test | 1 | 0.0% | 100.0% |
