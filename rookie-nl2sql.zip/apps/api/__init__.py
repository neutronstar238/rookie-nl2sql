"""
NL2SQL Web API Application
M12: FastAPI service with HTML/CSS frontend
"""
