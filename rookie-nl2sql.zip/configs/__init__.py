"""
configs package for NL2SQL system configuration.
"""
